import streamlit as st

from rag import ingest_file
from tools import ask_gemini, generate_summary, generate_flashcards


st.title("Generative AI Study Guide Agent")

st.write(
    "Upload course material and generate summaries, "
    "Q&A, and flashcards."
)

uploaded_file = st.file_uploader(
    "Upload course material",
    type=["pdf", "txt", "csv"]
)

level = st.selectbox(
    "Student level",
    ["beginner", "intermediate", "advanced"]
)

if uploaded_file is not None:

    if st.button("Process Material"):

        count = ingest_file(
            uploaded_file,
            uploaded_file.name
        )

        st.success(
            f"Successfully processed {count} chunks."
        )
    st.divider()

    st.subheader("Generate Study Guide")

    if st.button("Generate Summary"):

        summary = generate_summary(level)

        st.write(summary)

    if st.button("Generate Flashcards"):

        flashcards = generate_flashcards()

        st.write(flashcards)

    question = st.text_input(
        "Ask a question about your material"
    )

    if st.button("Ask Question"):

        if question:

            answer = ask_gemini(question)

            st.write(answer)