def ask_gemini(question):
    chunks = retrieve_chunks(question)  #Retrieve relevant chunks

    context = "\n\n".join(chunks)

    #Use the retrieved information from my PDF to answer the question.
    #This is the important part that makes it RAG,
    #rather than simply asking Gemini a general question

    prompt = f"""You are a study assistant helping a student understand course material.
    Use only the information provided in the context below.
    Context:{context}
    Question:{question}
    Give a clear and concise answer.
    If the context does not contain enough information to answer the question,
    say that the information is not available in the provided material."""

    client = _genai_client()

    response = client.models.generate_content(
        model="gemini-3.6-flash",
        contents=prompt
    )

    return response.text


def generate_summary(level):
    chunks = retrieve_chunks("main topics and important concepts")

    context = "\n\n".join(chunks)

    prompt = f"""You are an educational study-guide assistant.
    Student level: {level}
    Create a study summary using ONLY the information
    provided in the context.
    Context:{context}
    
    For a beginner:
    - Explain concepts simply.
    - Use easy language.
    - Include basic definitions.
    
    For an intermediate student:
    - Explain concepts clearly.
    - Include important relationships between concepts.
    
    For an advanced student:
    - Use more technical terminology.
    - Include deeper explanations and important details.
    
    Organize the summary with:
    - Main topics
    - Important concepts
    - Key definitions
    - Important points
    
    Do not add information that is not present in the context."""

    client = _genai_client()

    response = client.models.generate_content(
        model="gemini-3.6-flash",
        contents=prompt
    )

    return response.text


def generate_flashcards(level):
    chunks = retrieve_chunks("important concepts definitions key facts")

    context = "\n\n".join(chunks)

    prompt = f"""You are an educational study-guide assistant.
    Student level: {level}
    Create useful flashcards using ONLY the information in the context.
    Context:{context}
    Create 5 flashcards.
    Use exactly this format:
    
    Flashcard 1
    Question: ...
    Answer: ...
    
    Flashcard 2
    Question: ...
    Answer: ...
    
    Flashcard 3
    Question: ...
    Answer: ...
    
    Flashcard 4
    Question: ...
    Answer: ...
    
    Flashcard 5
    Question: ...
    Answer: ...
    
    Do not add information that is not present in the context."""

    client = _genai_client()

    response = client.models.generate_content(
        model="gemini-3.6-flash",
        contents=prompt
    )

    return response.text

